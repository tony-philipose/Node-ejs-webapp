var express = require('express');
var app = express();

app.get('/', function(req,res){
    res.send('<html><body>helloworld..</body></html>');
});

app.get('/a', function(req, res){
    res.send('reached');
});
app.post('/submit-data', function (req, res) {
    res.writeHead(404, {'Content-Type': 'text/html'});
    res.send('POST Request');
});

app.listen(8000, function(){
    console.log('running');
});