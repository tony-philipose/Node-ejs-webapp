var a =require('./area.js');
console.log(a());
//a.area('2');
//console.log("area is"+a.area('2') );
//console.log("area is"+a.area('2').calc());
//console.log(a.hai());