var mysql = require('mysql');
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"Assyst@123",
    database:"assignments"
});
con.connect(function(err) {
    if (err) console.log("error");

  //  var sql = "insert into qualification values (7, 'ma')";
    var up = "update qualification set `qualificationcol` = 'BBA' where `qid` = 1";

    con.query(up, function(err, result){
        if(err) console.log(err);
        console.log('sucess');
    })

    // con.query(sql, function (err, result) {
    //     if(err) console.error(err);
    //     console.log('insert sucessfully');
    // });

    con.query("SELECT * FROM qualification", function(err,results,feild){
        console.log(results);
        //console.log(feild);
    })

    console.log("Connected!");
  });