var m = require('./msg.js');
console.log(m);