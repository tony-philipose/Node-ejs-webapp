module.exports.log = function(msg1){
    console.log('------------log function----------');
 console.log(msg1);
};
module.exports.haiFn = function(obj1,obj2){
    console.log('------------hai function----------');
    console.log('this is obj 1 = '+obj1);

    console.log('this is ob2 from var = '+obj2);
};