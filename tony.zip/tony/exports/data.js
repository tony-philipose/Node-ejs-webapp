module.exports.stud = {
    fname: 'jon',
    lname: 'johny',
    class: '5'
}
module.exports.fn = function(obj1, obj2){
    console.log(obj1+obj2);
};