var s = require('./data.js');
var m =require('./msg.js');
console.log(s.stud.fname);
console.log(s.stud);
s.fn('m','n');
console.log(m);