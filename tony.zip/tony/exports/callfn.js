var fn = require('./msgfn.js');
fn.log("log fn calling fst");
var t = "hai this from var";
fn.haiFn('eeee',t);