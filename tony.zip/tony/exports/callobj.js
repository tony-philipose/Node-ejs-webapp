var m = require('./msgobj.js');
console.log('fst'+m);
console.log(m.msgOne);