$(document).ready(function(){
    console.log('script');
    //ajax for departments
    $.ajax({
        url : "/fetchallDepartment",
        type : "GET",
        success : function(data){
            var len = data.length;
            console.log('reach');
            //console.log(data);
            $("#Department").empty();
            $("#Department").append($("<option></option>")
            .attr("value", '').text('Select Department'));
            for(var i =0; i<len;i++){
            var value1 = data[i]['name'];
            var value2 = data[i]['id'];
                $("#Department").append("<option value='"+value2+"' >"+value1+"</option>");
            }
        }
    });

    //ajax for list whole employes
    $.ajax({
        url : "/employes/fetchallEmploye",
        type : "GET",
        success : function(data){
            var len = data.length;
            console.log('reach');
           // console.log(data);
            $("#Employe").empty();
            $("#Employe").append($("<option></option>")
            .attr("value", '').text('Select Employe'));
            for(var i =0; i<len;i++){
            var value1 = data[i]['fname'];
            var value2 = data[i]['id'];
                $("#Employe").append("<option value='"+value2+"' >"+value1+"</option>");
            }
        }
    });

    //----edit profile--------
    $("#updateProfile").hide();

    $('#profile input[type="text"]').prop("disabled", true);
    $('#profile input[type="date"]').prop("disabled", true);
    $('#profile input[type="email"]').prop("disabled", true);
    $('#profile input[type="number"]').prop("disabled", true);

    //editProfile
    $("#editProfile").click(function(){
        $('#profile input[type="date"]').prop("disabled", false);
        $('#profile input[type="email"]').prop("disabled", false);
        $('#profile input[type="text"]').prop("disabled", false);
        $('#profile #Designation').prop("disabled", true);
        // $('#profile #username').prop("disabled", true);
        // $('#profile #password').prop("disabled", true);
        $("#updateProfile").show();
        $("#editProfile").val('Cancel');
        $("#editProfile").attr("id", "cancel"); 
        $("#editProfile").attr("name", "cancel"); 

    }); 

    $("#cancel").click(function(){
        indow.location.href = '/employes/profile';
    });
});