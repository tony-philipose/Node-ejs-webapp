'use strict';
module.exports = (sequelize, DataTypes) => {
  const employe = sequelize.define('employe', {
    fname: DataTypes.STRING,
    lname: DataTypes.STRING,
    dob: DataTypes.STRING,
    salary: DataTypes.INTEGER,
    contact: DataTypes.INTEGER,
    designation: DataTypes.STRING,
    email: DataTypes.STRING,
    gender: DataTypes.STRING,
    departmentId: DataTypes.INTEGER
  }, {});
  employe.associate = function(models) {
    // associations can be defined here
    employe.belongsTo(models.department,{
      foreignKey: 'departmentId',
      onDelete: 'CASCADE',
    })
    employe.hasOne(models.login,{
      foreignKey: 'employeId',
      as: 'employe',
    })
  };
  return employe;
};