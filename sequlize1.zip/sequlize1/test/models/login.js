'use strict';
module.exports = (sequelize, DataTypes) => {
  const login = sequelize.define('login', {
    username: DataTypes.STRING,
    password: DataTypes.STRING,
    role: DataTypes.STRING,
    employeId: DataTypes.INTEGER,
    status: DataTypes.STRING
  }, {});
  login.associate = function(models) {
    // associations can be defined here
    login.belongsTo(models.employe,{
      foreignKey: 'employeId',

    });
  };
  return login;
};