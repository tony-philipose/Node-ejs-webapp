'use strict';
module.exports = (sequelize, DataTypes) => {
  const project = sequelize.define('project', {
    projectname: DataTypes.STRING,
    desc: DataTypes.STRING,
    startDate: DataTypes.STRING,
    endDate: DataTypes.STRING,
    status: DataTypes.STRING,
    employeId: DataTypes.INTEGER
  }, {});
  project.associate = function(models) {
    // associations can be defined here
  };
  return project;
};