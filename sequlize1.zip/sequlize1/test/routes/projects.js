var express = require('express');
var router = express.Router();
var models = require('../models');
var session = require('express-session');
var cookieSession = require('cookie-session');

router.get('/', function(req, res) {
    //res.render('projects');
    models.project.findAll({
  }).then(data => {
      console.log(data);
      res.render('projects',{
          detail:data
       });
    });
  });

router.post('/',addProjects);
router.get('/projects',viewProjects);

/*---Add new projects and assign it to an employe---*/
function addProjects(req,res){
  console.log(req.body.pjtName);
  models.project.create({
    projectname: req.body.pjtName,
    desc: req.body.Descripition,
    startDate: req.body.startDate,
    endDate: req.body.endDate,
    status: req.body.Status,
    employeId: req.body.Employe
  }).then(function() {
    res.redirect('/projects/');
  });
}  


/*----view project details of employes----*/
function viewProjects(req,res){
  models.project.findAll({
    where: {employeId: req.session.id}
}).then(data => {
    console.log(data);
    if( data !== null){
    res.render('workdetails',{
        detail:data
     });
    }else{
     // res.redirect('/employes/profile');noWork
      res.render('noWork');
    }
  });
}

module.exports = router;