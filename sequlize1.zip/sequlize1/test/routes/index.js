/*
* Author : Tony philipose
* Create on : 28-nov-18
* Reviwed by :
* index router is used for login account, verify the user
  login and redirect pages to the corresponding pages of 
  different user types, and logout .
*/

var express = require('express');
var router = express.Router();
var models = require('../models');
var session = require('express-session');
var cookieSession = require('cookie-session');

router.use(cookieSession({
    name: 'session',
    keys: ['key1', 'key2']
  }));

/* ---get the login page as the default page on loading-- */
router.get('/', function(req, res, next) {
  res.render('login', { title: 'Express' });
});

/* ---get/post listing for login activities--- */
router.post('/authentication',verifyLogin,redirectAccount);
router.get('/logout',logOut);

/*
 * verifyLogin and redirectAccount are the middleware functions
 * verifyLogin get login details using the username and password
 * then got to next or redirectAccount function. 
 */
function verifyLogin(req,res,next){
    models.login.findOne({
        where: {username: req.body.username,
            password:req.body.password}
    }).then(users => {
        res.user = users;
        next();
      });
}

/* 
* redirectAccount function check the login data or role
* and redirect the pages corresponds to the users.
*/
function redirectAccount(req,res){
    var data = res.user;
    if(data == null || data.length == 0){
        console.log('login err');
        res.redirect('/');
    }else{
        req.session.id=data.employeId;
        console.log(req.session.id);
        if(data.role == 'engineer'){
          res.redirect('/employes/profile');
        }else if(data.role == 'hr'){
            res.redirect('/employes/registeration');
        }else{
            console.log('role login');
            res.redirect('/');
        }
    }
}

/* 
* logout function for logging out and set null 
* to the session varibles.
*/
function logOut(req,res){
  console.log(req.session.id);
  req.session = null;
  res.redirect('/');
}

/* #### Department routing functions below ##### */

/*----get department page----*/
router.get('/department', function(req, res, next) {
  res.render('newdept', { title: 'dept' });
});

/*
* Add new department to department model 
* and redirect to the same page
*/
router.post('/department', function(req, res, next) {
  models.department.create({
    name: req.body.deptName,
    strenth: req.body.deptStrngth
  }).then(function() {
    res.redirect('/department');
  });
});

/*
* get all departments from department model and
* send the data to a ajax function.
 */
router.get('/fetchallDepartment',function(req,res){
  console.log('is');
  models.department.findAll({
  }).then(department => {
      res.json(department);
    });
});

module.exports = router;
