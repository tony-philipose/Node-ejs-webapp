/*
* Author : Tony philipose
* Create on : 28-nov-18
* Reviwed by :
* employe router is include add new employes, get employe
* details, get all employe etc.*
*/

var express = require('express');
var router = express.Router();
var models = require('../models');
var session = require('express-session');
var cookieSession = require('cookie-session');

/* ---get the employe register page -- */
router.get('/registeration', function(req, res, next) {
    res.render('register', { title: 'Express' });
  });

/* ---get/post listing for employe --- */
router.post('/registeration',addEmploye, gethmaxId, createLogin);
router.get('/profile',viewProfile);
router.post('/profile',updateProfile,updateLogin);

/*
* To register the employes using the middleware functions
* function addEmploye is to store the new employe details.
*/
  function addEmploye(req, res, next) {
    models.employe.create({
      fname: req.body.firstName,
      lname: req.body.lastName,
      dob: req.body.dob,
      salary: req.body.Salary,
      contact: req.body.contactNo,
      designation: req.body.Designation,
      email: req.body.email,
      gender: req.body.gender,
      departmentId: req.body.Department
    }).then(function() {
      return next();
    });
}

/*
* fetch the last inserted id o the employe model 
* for inserting employeID into login table 
*/
function gethmaxId(req,res,next){
  models.employe.max('id').then(max => {
    console.log(max);
    res.id = max;
    next();
  })
  
}

/* 
* inserting credentialls into login model with 
* max Id of employe model as foriegn key
*/
function createLogin(req,res){
  var value = res.id;
  console.log('value is'+value);
  models.login.create({
    username: req.body.firstName,
    password: req.body.lastName,
    role: 'engineer',
    employeId: value,
    status: 'active'
  }).then(function() {
    res.redirect('/employes/registeration');
  });
}  

/* ---Get the profile of a employe from the employe model--- */
function viewProfile(req,res){
    console.log(req.session.id);
    //models.employe.hasOne(models.login, {foreignKey: 'employeId', as: 'login'});

    console.log(req.session.id);
    models.login.findOne({
      where: {employeId: req.session.id},
      include: [{model: models.employe, as: 'employe'}]
  }).then(data => {
        console.log(data)
        res.render('profile',{
            detail:data
         });
      });
}

/* updateProfile */
function updateProfile(req,res,next){
    console.log(req.session.id);
      models.employe.update({
            fname: req.body.firstName,
            lname: req.body.lastName,
            dob: req.body.dob,
            contact: req.body.contactNo,
            email: req.body.email,
      }, {
        where: {
            id: req.session.id,
        }
      }).then(function() {
        //res.redirect('/employes/profile');
        return next();
      });
}

function updateLogin(req,res){
    models.login.update({
      username: req.body.username,
    password: req.body.password
    }, {
    where: {
      employeId: req.session.id,
    }
    }).then(function() {
    res.redirect('/employes/profile');
    });
}


/*--------fetch all employes from the employe model-------*/ 
router.get('/fetchallEmploye',function(req,res){
    console.log('is');
    models.employe.findAll({
    }).then(employes => {
        res.json(employes);
      });
  });

module.exports = router;